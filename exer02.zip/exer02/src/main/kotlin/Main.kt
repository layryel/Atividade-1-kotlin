package exercicio2
fun main(args: Array<String>) {
    var a: Int
    var b = 2
    a = 10
    print(a+b)
}