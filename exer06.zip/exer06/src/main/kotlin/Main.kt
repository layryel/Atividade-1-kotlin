package exercicio06
fun main(args: Array<String>) {
    val bomHumor = true
    print("Hoje estou ${if (bomHumor) "feliz" else "chateado"}")
}