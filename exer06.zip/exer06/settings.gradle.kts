
rootProject.name = "exer06"

